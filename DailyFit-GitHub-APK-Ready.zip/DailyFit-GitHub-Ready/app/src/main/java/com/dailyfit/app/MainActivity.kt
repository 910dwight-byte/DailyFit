package com.dailyfit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

data class Exercise(val name:String,val seconds:Int,val description:String)
data class Workout(val title:String,val exercises:List<Exercise>)

val workouts=listOf(
 Workout("Full Body",listOf(
  Exercise("Bodyweight Squats",40,"Lower into a comfortable squat and stand tall."),
  Exercise("Push-ups",30,"Use a comfortable variation and keep your body aligned."),
  Exercise("Reverse Lunges",40,"Step back softly and alternate legs."),
  Exercise("Mountain Climbers",30,"From a plank, alternate bringing knees forward."),
  Exercise("Glute Bridge",40,"Lift your hips slowly while lying on your back."),
  Exercise("Plank",30,"Brace your core and breathe steadily.")
 )),
 Workout("Core + Cardio",listOf(
  Exercise("March in Place",45,"Stand tall and alternate lifting your knees."),
  Exercise("Dead Bug",40,"Slowly extend opposite arm and leg from your back."),
  Exercise("Mountain Climbers",30,"Alternate driving your knees toward your chest."),
  Exercise("Bird Dog",40,"Extend opposite arm and leg from hands and knees."),
  Exercise("Plank",30,"Keep your body aligned and breathe steadily.")
 )),
 Workout("Lower Body",listOf(
  Exercise("Bodyweight Squats",45,"Lower with control and stand tall."),
  Exercise("Reverse Lunges",40,"Alternate legs and move comfortably."),
  Exercise("Glute Bridge",45,"Lift your hips with control."),
  Exercise("Calf Raises",40,"Rise onto your toes and lower slowly."),
  Exercise("Wall Sit",30,"Hold a comfortable seated position.")
 )),
 Workout("Upper Body",listOf(
  Exercise("Push-ups",35,"Use a comfortable variation."),
  Exercise("Incline Push-ups",35,"Use a sturdy surface and move with control."),
  Exercise("Plank Shoulder Taps",30,"Gently tap opposite shoulders."),
  Exercise("Superman",30,"Gently lift arms and legs while lying on your stomach."),
  Exercise("Plank",30,"Brace your core and breathe steadily.")
 ))
)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{DailyFit()}}
}

@Composable fun DailyFit(){
 var tab by remember{mutableStateOf(0)}
 var workout by remember{mutableStateOf(workouts[LocalDate.now().dayOfYear%workouts.size])}
 var exercise by remember{mutableStateOf(0)}
 var running by remember{mutableStateOf(false)}
 var seconds by remember{mutableStateOf(workout.exercises[0].seconds)}
 var completed by remember{mutableStateOf(0)}
 Scaffold(
  topBar={TopAppBar(title={Text("DailyFit",fontWeight=FontWeight.Bold)})},
  bottomBar={NavigationBar{
   NavigationBarItem(tab==0,{tab=0},{},{Text("Today")})
   NavigationBarItem(tab==1,{tab=1},{},{Text("Progress")})
   NavigationBarItem(tab==2,{tab=2},{},{Text("Settings")})
  }}
 ){p->
  when(tab){
   0->Home(p,workout){exercise=0;seconds=workout.exercises[0].seconds;running=false;tab=3}
   1->Column(Modifier.padding(p).padding(20.dp)){Text("Progress",fontSize=34.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Text("$completed workouts completed",fontSize=20.sp)}
   2->Column(Modifier.padding(p).padding(20.dp)){Text("Settings",fontSize=34.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Text("DailyFit V1 • Offline")}
   else->WorkoutScreen(p,workout,exercise,seconds,running,{running=!running},{
    if(exercise<workout.exercises.lastIndex){exercise++;seconds=workout.exercises[exercise].seconds}else{completed++;tab=0}
   })
  }
 }
}

@Composable fun Home(p:PaddingValues,w:Workout,start:()->Unit){
 Column(Modifier.fillMaxSize().padding(p).padding(20.dp)){
  Text("Today",fontSize=34.sp,fontWeight=FontWeight.Bold)
  Text("Your daily bodyweight workout",color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(20.dp))
  Card(Modifier.fillMaxWidth(),RoundedCornerShape(24.dp)){
   Column(Modifier.padding(22.dp)){
    Text(w.title,fontSize=26.sp,fontWeight=FontWeight.Bold)
    Text("${w.exercises.size} exercises • No equipment",Modifier.padding(vertical=8.dp))
    Button(start,Modifier.fillMaxWidth()){Text("START WORKOUT")}
   }
  }
 }
}

@Composable fun WorkoutScreen(p:PaddingValues,w:Workout,i:Int,s:Int,r:Boolean,toggle:()->Unit,next:()->Unit){
 Column(Modifier.fillMaxSize().padding(p).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){
  Text("Exercise ${i+1} of ${w.exercises.size}")
  Spacer(Modifier.height(28.dp))
  Text(w.exercises[i].name,fontSize=30.sp,fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(12.dp))
  Text(w.exercises[i].description,fontSize=17.sp)
  Spacer(Modifier.height(32.dp))
  Text("${s}s",fontSize=64.sp,fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(20.dp))
  Button(toggle,Modifier.fillMaxWidth()){Text(if(r)"PAUSE" else "START TIMER")}
  OutlinedButton(next,Modifier.fillMaxWidth().padding(top=10.dp)){Text(if(i==w.exercises.lastIndex)"FINISH" else "NEXT")}
 }
}
