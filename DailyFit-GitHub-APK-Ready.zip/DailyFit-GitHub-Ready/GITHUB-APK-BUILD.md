# DailyFit GitHub APK

Upload the contents of this folder to a GitHub repository.

Then open Actions → Build DailyFit APK → Run workflow.

When it finishes, open the workflow run and download the `DailyFit-debug-apk` artifact. Extract it to get `app-debug.apk`.

This is a debug/testing APK. A signed release build for Google Play should be configured separately.
